package slit.ejb.module;

import java.io.Serializable;



/**
 *
 * @author evenal
 */
public class Module implements Serializable
{

}
